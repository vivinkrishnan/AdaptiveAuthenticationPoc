package com.ibm.mfpstartercordova;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.net.URI;

import org.apache.cordova.CordovaActivity;

import com.worklight.androidgap.api.WL;
import com.worklight.androidgap.api.WLInitWebFrameworkResult;
import com.worklight.androidgap.api.WLInitWebFrameworkListener;

import com.ibm.MFPApplication;

public class MainActivity extends CordovaActivity implements WLInitWebFrameworkListener {

	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);

        if (!((MFPApplication)this.getApplication()).hasCordovaSplashscreen()) {
            WL.getInstance().showSplashScreen(this);
        }

        init();

		WL.getInstance().initializeWebFramework(getApplicationContext(), this);

		printProperties();

		Context context = getApplicationContext();
		File file = context.getFilesDir();
		Log.i("File Name", file.getName());
		Log.i("File Directory", String.valueOf(file.isDirectory()));

		File[] fileList = file.listFiles();
		for(File f: fileList){
			Log.i("File List Name", f.getName());
			if(f.isDirectory()){
				Log.i("File canRead", String.valueOf(f.canRead()));
				printDirectoryFiles(f.getPath());
			}
		}

		String[] strFileList = context.fileList();
		for(String s: strFileList){
			Log.i("File Str", s);
		}



	}

	public void printDirectoryFiles(String filePath){
		Log.i("File Path", filePath);
		AssetManager am = getAssets();

		try {

			String list[] = am.list(filePath);
			Log.i("FILES", String.valueOf(list.length));

			if (list != null)
				for (int i=0; i<list.length; ++i)
				{
					Log.i("FILE:", filePath +"/"+ list[i]);
				}

		} catch (IOException e) {
			Log.v("List error:", "can't list" + ".");
		}
	}

	public void printProperties(){
		Log.i("TAG", "SERIAL: " + Build.SERIAL);
		Log.i("TAG","MODEL: " + Build.MODEL);
		Log.i("TAG","DEVICE: " + Build.DEVICE);
		Log.i("TAG","DISPLAY: " + Build.DISPLAY);
		Log.i("TAG","HARDWARE: " + Build.HARDWARE);
		Log.i("TAG","TIME: " + Build.TIME);
		Log.i("TAG","ID: " + Build.ID);
		Log.i("TAG","Manufacture: " + Build.MANUFACTURER);
		Log.i("TAG","brand: " + Build.BRAND);
		Log.i("TAG","type: " + Build.TYPE);
		Log.i("TAG","user: " + Build.USER);
		Log.i("TAG","BASE: " + Build.VERSION_CODES.BASE);
		Log.i("TAG","INCREMENTAL " + Build.VERSION.INCREMENTAL);
		Log.i("TAG","SDK  " + Build.VERSION.SDK);
		Log.i("TAG","BOARD: " + Build.BOARD);
		Log.i("TAG","BRAND " + Build.BRAND);
		Log.i("TAG","HOST " + Build.HOST);
		Log.i("TAG","FINGERPRINT: "+Build.FINGERPRINT);
		Log.i("TAG","Version Code: " + Build.VERSION.RELEASE);

		String[] supported32BitAbis = Build.SUPPORTED_32_BIT_ABIS;
		String[] supported64BitAbis = Build.SUPPORTED_64_BIT_ABIS;
		String[] supportedAbis = Build.SUPPORTED_ABIS;

		for(String s32: supported32BitAbis){
			Log.i("TAG","32bit ::" + s32);
		}

		for(String s64: supported64BitAbis){
			Log.i("TAG","64bit ::" + s64);
		}

		for(String sabi: supportedAbis){
			Log.i("TAG","abi ::" + sabi);
		}
	}

	/**
	 * The IBM MobileFirst Platform calls this method after its initialization is complete and web resources are ready to be used.
	 */
 	public void onInitWebFrameworkComplete(WLInitWebFrameworkResult result){
		if (result.getStatusCode() == WLInitWebFrameworkResult.SUCCESS) {
		    final String mainHtmlFilePath = WL.getInstance().getMainHtmlFilePath();
		    // wi00199: Fix for Ionic Webview WhiteScreen issue. Check whether the app in Ionic and it is not loaded with
		    // 			default url, If yes, update the Ionic base path instead of calling loadurl API.
            if (WL.getInstance().isIonicWebview() && !mainHtmlFilePath.toLowerCase().contains("/android_asset/www")) {
                try {
					String webviewUrlPath = new URI(mainHtmlFilePath).getPath();
					String webviewServerPath = webviewUrlPath.substring(0, webviewUrlPath.indexOf("/index.html"));
					WL.getInstance().updateIonicBasePath(webviewServerPath, appView, this);
                }
				 catch (Exception EX) {
					 super.loadUrl(mainHtmlFilePath);
                 }
			}
            else {
				super.loadUrl(mainHtmlFilePath);
			}
		} else {
			handleWebFrameworkInitFailure(result);
		}
	}

	private void handleWebFrameworkInitFailure(WLInitWebFrameworkResult result){
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
		alertDialogBuilder.setNegativeButton(R.string.close, new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which){
				finish();
			}
		});

		alertDialogBuilder.setTitle(R.string.error);
		alertDialogBuilder.setMessage(result.getMessage());
		alertDialogBuilder.setCancelable(false).create().show();
	}
}
