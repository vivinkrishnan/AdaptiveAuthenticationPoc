
	var Messages = {
	// Add here your messages for the default language.
	// Generate a similar file with a language suffix containing the translated messages.
	// key1 : message1,
	};

	var wlInitOptions = {
	// Options to initialize with the WL.Client object.
	// For initialization options please refer to IBM MobileFirst Platform Foundation Knowledge Center.
	};

	function wlCommonInit() {
	app.init();
	}

	var app = {
	//initialize app
	"init": function init() {
	var buttonElement = document.getElementById("ping_button");
	buttonElement.style.display = "block";
	buttonElement.addEventListener('click', app.testServerConnection, false);
	},
	//test server connection
	"testServerConnection": function testServerConnection() {

	var titleText = document.getElementById("main_title");
	var statusText = document.getElementById("main_status");
	var infoText = document.getElementById("main_info");
	titleText.innerHTML = "Hello World";
	statusText.innerHTML = "Connecting to Server...";
	infoText.innerHTML = "";

	var attributeSet = {};
	attributeSet.app = {};
	attributeSet.user = {};
	attributeSet.device = {};

	navigator.globalization.getPreferredLanguage(function (language) {
	    console.log('>>>>>> ::: Device language: ' + language.value + '\n');
		attributeSet.device.language = language.value;

		navigator.globalization.getLocaleName(function (locale) {
		    console.log('>>>>>> ::: Device locale: ' + locale.value + '\n');
			attributeSet.device.locale = locale.value;
			attributeSet.device.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

			console.log(">>>>>>" + Intl.DateTimeFormat().resolvedOptions().timeZone);

			var physicalScreenWidth = window.screen.width * window.devicePixelRatio;
			var physicalScreenHeight = window.screen.height * window.devicePixelRatio;

			console.log(">>>>>> Screen size:::" + physicalScreenHeight + "------" + physicalScreenWidth );

            attributeSet.device.screenSize = {};
			attributeSet.device.screenSize.height = physicalScreenHeight;
            attributeSet.device.screenSize.width = physicalScreenWidth;

			var offset = new Date().getTimezoneOffset();
			console.log(">>>>>> :::" + offset);

			attributeSet.device.timeZoneOffset = offset;

			console.log(">>>>>> Navigator Language:::" + navigator.language);
			attributeSet.device.language = navigator.language;
			attributeSet.device.model = device.model;
			attributeSet.device.platform = device.platform;
			attributeSet.device.uuid = device.uuid;
			attributeSet.device.version = device.version;
			attributeSet.device.manufacturer = device.manufacturer;
			attributeSet.device.isVirtual = device.isVirtual;
			attributeSet.device.serial = device.serial;
			attributeSet.device.sdkVersion = device.sdkVersion;

			attributeSet.device.location = {};

			navigator.geolocation.getCurrentPosition(function(position){
			    console.log('Latitude: '          + position.coords.latitude          + '\n' +
                'Longitude: '         + position.coords.longitude         + '\n' +
                'Timestamp: '         + position.timestamp                + '\n');

				attributeSet.device.location.latitude = position.coords.latitude;
				attributeSet.device.location.longitude = position.coords.longitude;
				attributeSet.device.location.timestamp = position.coords.timestamp;

				networkinterface.getIPAddress(function (ip) {

				    console.log(JSON.stringify(ip.ip));
				    attributeSet.user.ip = ip.ip;

				    cordova.getAppVersion.getAppName().then(function(name){
                                    				  // My App Name
                        console.log(">>>>>>> App Name ::: " + name);
                        attributeSet.app.appname = name;

                        cordova.getAppVersion.getPackageName().then(function(pkgname){
                            // com.companyname.appname
                            console.log(">>>>>>> Package Name ::: " + pkgname);
                            attributeSet.app.pkgname = pkgname;

                            cordova.getAppVersion.getVersionNumber().then(function(versionNumber){
                                // 1.0.0
                                console.log(">>>>>>> version number :::" + versionNumber);
                                attributeSet.app.versionNumber = versionNumber;

                                cordova.getAppVersion.getVersionCode().then(function(version){
                                // 10000
                                    console.log(">>>>>>> version code ::: " + version);
                                    attributeSet.app.versionCode = version;

                                    WLJQ.get( "https://api.ipify.org?format=json",function(data){
                                                 //alert(data.ip) ;

                                        console.log(">>>>>>>>> ip ::::" + data.ip);
                                        attributeSet.user.ip = data.ip;

                                        UserAgent.get(function(ua){

                                            attributeSet.device.useragent = ua;
                                            console.log(">>>>>>>> ua :::" + ua);

                                            console.log(JSON.stringify(cordova.file));


											//Change the URL to reflect the REST endpoint exposed by the server
                                            var resourceRequest = new WLResourceRequest("http://192.168.1.3:8080/testJSON",
                                                                                                                  WLResourceRequest.POST);
                                            var formParams = JSON.stringify(attributeSet);
                                            resourceRequest.setHeader("Content-type","application/json");

                                            resourceRequest.send(formParams).then(
                                                function(response) {
                                                    statusText.innerHTML = JSON.stringify(response);
                                                },
                                                function(err) {
                                                    statusText.innerHTML = JSON.stringify(err);
                                                }
                                            );
                                        });




                                    });


                                });

                            });

                        });

                    });

				});

			},function(error){
			    console.log('code: '    + error.code    + '\n' +
				'message: ' + error.message + '\n');
			});

		}, function () {
		    console.log('Error getting locale\n');
		});

	}, function () {
	    console.log('>>>>>> ::: Error getting language\n');
	});

	},

}




